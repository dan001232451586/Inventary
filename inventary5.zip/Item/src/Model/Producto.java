package Model;

public class Producto {
private String nombre;
    private double precio;
    private int cantidad;
    private String fecha;


    public Producto(String nombre, double precio, int cantidad, String fecha) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.fecha = fecha;
    }

        }

