package Model;

public class Usuario {
    private final String usuario;
    private final String contraseña;
    private boolean isAdmin;

    public Usuario(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.isAdmin = false;
    }
    
    public Usuario(String usuario, String contraseña, boolean isAdmin) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.isAdmin = isAdmin;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }
}
