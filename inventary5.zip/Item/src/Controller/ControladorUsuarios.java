package Controller;

import Model.Usuario;
import java.util.ArrayList;
import java.util.List;

public class ControladorUsuarios {
    private final List<Usuario> usuarios;

    public ControladorUsuarios() {
        this.usuarios = new ArrayList<>();
        // Por defecto, agregamos un usuario administrador
        usuarios.add(new Usuario("admin", "admin", true));
    }

    public boolean crearUsuario(String usuario, String contraseña) {
        // Verificamos si el usuario ya existe
        for (Usuario u : usuarios) {
            if (u.getUsuario().equals(usuario)) {
                return false; // El usuario ya existe
            }
        }
        // Creamos el nuevo usuario y lo agregamos a la lista
        usuarios.add(new Usuario(usuario, contraseña));
        return true; // Usuario creado exitosamente
    }

    Iterable<Usuario> getUsuarios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

