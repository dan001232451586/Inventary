package Controller;



import Model.Usuario;
import View.VistaInicioSesion;
import View.VistaInventario;

import javax.swing.JOptionPane;

public class ControladorInicioSesion {
    private final VistaInicioSesion vista;
    private final VistaInventario vistaInventario;
    private final ControladorUsuarios controladorUsuarios;

    public ControladorInicioSesion(VistaInicioSesion vista, VistaInventario vistaInventario) {
        this.vista = vista;
        this.vistaInventario = vistaInventario;
        this.controladorUsuarios = new ControladorUsuarios();
        this.vista.setControlador(this);
    }

    public void iniciarSesion(String usuario, String contraseña) {
        // Verificar si el usuario es administrador
        if (usuario.equals("admin") && contraseña.equals("admin")) {
            vistaInventario.mostrarVentana();
            vista.cerrarVentana();
        } else {
            // Intentar iniciar sesión con el usuario proporcionado
            if (validarCredenciales(usuario, contraseña)) {
                vistaInventario.mostrarVentana();
                vista.cerrarVentana();
            } else {
                JOptionPane.showMessageDialog(null, "Credenciales incorrectas. Por favor, inténtelo de nuevo.");
            }
        }
    }

    public boolean validarCredenciales(String usuario, String contraseña) {
        // Verificar si las credenciales coinciden con algún usuario existente
        for (Usuario u : controladorUsuarios.getUsuarios()){
            if (u.getUsuario().equals(usuario) && u.getContraseña().equals(contraseña)) {
                return true; // Credenciales válidas
            }
        }
        return false; // Credenciales inválidas
    }

    public boolean crearUsuario(String usuario, String contraseña) {
        // Intentar crear el usuario
        if (controladorUsuarios.crearUsuario(usuario, contraseña)) {
            JOptionPane.showMessageDialog(null, "Usuario creado exitosamente.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "El usuario ya existe.");
            return false;
        }
    }
}
