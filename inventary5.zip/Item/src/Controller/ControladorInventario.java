package Controller;

import Model.Producto;
import View.VistaInventario;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class ControladorInventario {
    private final VistaInventario vista;
    private final List<Producto> inventario;

    public ControladorInventario(VistaInventario vista) {
        this.vista = vista;
        this.inventario = new ArrayList<>();
        this.vista.setControlador(this);
    }

    public void agregarProducto(String nombre, double precio, int cantidad, String fecha) {
        Producto producto = new Producto(nombre, precio, cantidad, fecha);
        inventario.add(producto);
        JOptionPane.showMessageDialog(null, "Producto agregado al inventario.");
    }
}

