package View;

import Controller.ControladorInicioSesion;
import javax.swing.*;

public class VistaInicioSesion {
    private final JFrame ventana;
    private final JTextField campoUsuario;
    private final JPasswordField campoContraseña;
    private final ControladorInicioSesion controlador;

    public VistaInicioSesion(ControladorInicioSesion controlador) {
        this.controlador = controlador;

        ventana = new JFrame("Inicio de Sesión");
        ventana.setSize(300, 200);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLayout(null);

        JLabel etiquetaUsuario = new JLabel("Usuario:");
        etiquetaUsuario.setBounds(30, 30, 80, 25);
        ventana.add(etiquetaUsuario);

        campoUsuario = new JTextField();
        campoUsuario.setBounds(110, 30, 150, 25);
        ventana.add(campoUsuario);

        JLabel etiquetaContraseña = new JLabel("Contraseña:");
        etiquetaContraseña.setBounds(30, 70, 80, 25);
        ventana.add(etiquetaContraseña);

        campoContraseña = new JPasswordField();
        campoContraseña.setBounds(110, 70, 150, 25);
        ventana.add(campoContraseña);

        JButton botonIniciarSesion = new JButton("Iniciar Sesión");
        botonIniciarSesion.setBounds(100, 120, 120, 25);
        botonIniciarSesion.addActionListener(e -> {
            String usuario = campoUsuario.getText();
            String contraseña = new String(campoContraseña.getPassword());
            controlador.iniciarSesion(usuario, contraseña);
        });
        ventana.add(botonIniciarSesion);
    }

    VistaInicioSesion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setControlador(ControladorInicioSesion controlador) {
        this.controlador = controlador;
    }

    public void mostrarVentana() {
        ventana.setVisible(true);
    }

    public void cerrarVentana() {
        ventana.dispose();
    }
}
