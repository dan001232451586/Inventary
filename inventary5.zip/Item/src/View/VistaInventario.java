package View;

import Controller.ControladorInventario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class VistaInventario {
    private final JFrame ventana;
    private JTextField campoNombre;
    private JTextField campoPrecio;
    private JTextField campoCantidad;
    private JTextField campoFecha;
    private ControladorInventario controlador;

    public VistaInventario() {
        ventana = new JFrame("Inventario");
        ventana.setSize(400, 300);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLayout(new BorderLayout());

        JPanel panelCentral = new JPanel(new GridLayout(5, 2));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel etiquetaNombre = new JLabel("Nombre:");
        campoNombre = new JTextField();
        JLabel etiquetaPrecio = new JLabel("Precio:");
        campoPrecio = new JTextField();
        JLabel etiquetaCantidad = new JLabel("Cantidad:");
        campoCantidad = new JTextField();
        JLabel etiquetaFecha = new JLabel("Fecha:");
        campoFecha = new JTextField();

        JButton botonAgregarProducto = new JButton("Agregar Producto");
        botonAgregarProducto.addActionListener((ActionEvent e) -> {
            String nombre = campoNombre.getText();
            double precio = Double.parseDouble(campoPrecio.getText());
            int cantidad = Integer.parseInt(campoCantidad.getText());
            String fecha = campoFecha.getText();
            controlador.agregarProducto(nombre, precio, cantidad, fecha);
        });

        panelCentral.add(etiquetaNombre);
        panelCentral.add(campoNombre);
        panelCentral.add(etiquetaPrecio);
        panelCentral.add(campoPrecio);
        panelCentral.add(etiquetaCantidad);
        panelCentral.add(campoCantidad);
        panelCentral.add(etiquetaFecha);
        panelCentral.add(campoFecha);
        panelCentral.add(new JLabel());
        panelCentral.add(botonAgregarProducto);

        ventana.add(panelCentral, BorderLayout.CENTER);
    }

    public void mostrarVentana() {
        ventana.setVisible(true);
    }

    public void cerrarVentana() {
        ventana.dispose();
    }

    public void setControlador(ControladorInventario controlador) {
        this.controlador = controlador;
    }
}

